package com.codingdojo.Relationships.repository;

//import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.codingdojo.Relationships.models.License;

import java.util.List;

@Repository
public interface LicensesRepository extends CrudRepository<License, Integer> {
	List<License> findAll();
}

